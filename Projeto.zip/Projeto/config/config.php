<?php
return [
    'host' => 'localhost',
    'db_name' => 'Local Instance MySQL80',
    'username' => 'root',
    'password' => ''

];